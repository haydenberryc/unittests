﻿namespace Users.Api.Options;

public class DbConnectionOptions
{
    public string ConnectionString { get; init; } = default!;
}
