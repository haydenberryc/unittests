﻿namespace Users.Api.Contracts;

public class CreateUserRequest
{
    public string FullName { get; init; } = default!;
}
