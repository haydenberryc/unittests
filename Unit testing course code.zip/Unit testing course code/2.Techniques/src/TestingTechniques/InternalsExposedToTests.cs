﻿using System.Runtime.CompilerServices;

//[assembly: InternalsVisibleTo("TestingTechniques.Tests.Unit")]
